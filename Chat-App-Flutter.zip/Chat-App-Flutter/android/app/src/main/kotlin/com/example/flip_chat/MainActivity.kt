package com.example.flip_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
