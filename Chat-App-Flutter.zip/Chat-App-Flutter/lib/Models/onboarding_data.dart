List<String> images = [
  "assets/images/onboarding1.png",
  "assets/images/onboarding2.png",
  "assets/images/onboarding3.png"
];

List<String> HeadingText1 = [
  "Introducing FlipChat",
  "Your Ultimate Fashion\nFix",
  "Trendy\nRecommendations...\nAnytime!"
];

List<String> HeadingText2 = [
  "Meet FlipChat, your personal, next-gen Conversational Fashion Outfit Generator. \n\nElevate your fashion game with FlipChat, now seemlessly integrated with Flipkart 😉",
  "Confused about today? We,ve got you covered! \n\nDiscover your Unique Style with trendsetting recommendations and Occasion-Ready Ensembles, all at one place.",
  "Revolutionize the way you shop for fashion with FlipChat. Your fashion journey starts here.\nGet ready to slay, one outfit at a time! 💃✨"
];

