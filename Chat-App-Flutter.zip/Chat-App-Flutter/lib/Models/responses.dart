List<String> hardcodedResponses = [
  "Hello, how can I assist you today?",
  "Feel free to ask me anything!",
  "I'm a prototype chatbot.",
  "You're welcome! I'm glad I could help. Have a fantastic time at the party, and if you need more advice in the future, I'm here to assist!",
// Add more responses as needed
];

List<String> initialPrompts = [

  "Suggest me some bridal accessories",
  "What\'s trending lately...",
  "Casual outfit for today",
  // Add more prompts as needed
];