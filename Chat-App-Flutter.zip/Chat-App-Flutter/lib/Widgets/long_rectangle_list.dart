import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class LongRectangeList extends StatefulWidget {
  const LongRectangeList({Key? key, required this.isimageSet2}) : super(key: key);

  final bool isimageSet2;

  @override
  State<LongRectangeList> createState() => _LongRectangeListState();
}

class _LongRectangeListState extends State<LongRectangeList> {

  Future <void> _launchURL(String url) async{
    final Uri uri = Uri(scheme: "https" , host: url);
    if(!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )){
      throw "Can not launch url";
    }
  }
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 280,
      child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemCount: imageSet1.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: (){
                _launchURL("www.flipkart.com");
              },
              child: Column(
                children: [
                  Container(
                    height: 254,
                    width: 180,
                    margin: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.withOpacity(0.5)),
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(borderRadius: BorderRadius.only(topRight: Radius.circular(13.0), topLeft: Radius.circular(13.0)),
                            child: Image.asset(widget.isimageSet2? imageSet2[index]: imageSet1[index],fit: BoxFit.fill, height: 202, width: 180,)),
                        Spacer(),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.withOpacity(0.5)),
                            color: Colors.white,
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(0), bottomRight: Radius.circular(13.0), bottomLeft: Radius.circular(13.0)),
                          ),
                          height: 50.0,
                          width: 180,
                          child: Center(child: Text('View Product', style: TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),
    );
  }
}

List <String> imageSet1 =['assets/images/dress1.jpg','assets/images/dress2.jpg','assets/images/dress3.jpg'];
List <String> imageSet2 =['assets/images/formal1.jpg', 'assets/images/formal2.jpg', 'assets/images/formal3.jpg'];
