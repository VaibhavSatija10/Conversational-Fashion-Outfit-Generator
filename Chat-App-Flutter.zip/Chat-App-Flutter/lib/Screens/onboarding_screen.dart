import 'package:flip_chat/Models/onboarding_data.dart';
import 'package:flip_chat/screens/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

late PageController _pageController;
int activePage =1;
bool isLastPage = false;

class Onboarding_Page extends StatefulWidget {
  const Onboarding_Page({super.key});

  @override
  State<Onboarding_Page> createState() => _Onboarding_PageState();
}

class _Onboarding_PageState extends State<Onboarding_Page> {

  @override

  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 1, initialPage: 0);
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return  Scaffold(
      //backgroundColor: Colors.black,
      appBar: null,
      body:  Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xffFCFDFF),
              Color(0xff047BD5),
            ],
          ),
        ),
        child: Stack(
          children: [

            Positioned(
              bottom: 50, left: 30,
                child: Row(
                  children: [
                    SmoothPageIndicator(
                      controller: _pageController,
                      count: images.length,
                      effect: const WormEffect(
                        spacing: 12,
                        dotColor:Color(0xffdddddd),
                        activeDotColor:  Color(0xffffffff),
                        dotHeight: 10,
                        dotWidth: 10,
                      ),
                      onDotClicked: (index)=>_pageController.animateToPage(index, duration: const Duration(microseconds: 500), curve: Curves.easeIn),
                    ),
                    //TODO: Add the next circle animator here.
                  ],
                ),
            ),
            PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (index){
                  setState(() {
                    isLastPage = index ==2;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 30),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only( top: 40),
                              child:
                              isLastPage ? Container(height: 40):
                              TextButton(
                                  onPressed: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
                                  },
                                child:  Text(
                                  'SKIP >>',
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.6),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 30),
                        Image.asset(images[pagePosition],height: height*0.42,width: width*0.9,fit: BoxFit.fill,),
                        SizedBox(
                          height: 104,
                          child: Text(HeadingText1[pagePosition],
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white)),
                        ),
                        SizedBox(height: 10),
                        SizedBox(
                          height: 140,
                          child: Text(HeadingText2[pagePosition],
                              textAlign: TextAlign.start,
                              style: TextStyle(fontSize: 16, color: Colors.white)),
                        ),
                        if(isLastPage)
                            Padding(
                              padding: const EdgeInsets.only(right: 10.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  CircleAvatar(
                                    backgroundColor: Colors.white,
                                    radius: 29,
                                    child: IconButton(icon: Icon(Icons.arrow_forward_ios_rounded, color: Color(0xff222222),), onPressed: (){
                                      Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
                                    },),
                                  ),
                                ],
                              ),
                            ),
                        (!isLastPage) ? SizedBox(height: height*0.05,):SizedBox(height: height*0.04,) ,
                      ],
                    ),
                  );
                }
            ),
          ],
        ),
      ),
    );
  }
}