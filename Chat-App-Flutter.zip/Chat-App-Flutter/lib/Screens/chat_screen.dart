import 'package:flip_chat/Models/responses.dart';
import 'package:flip_chat/Screens/initial_chat_prompt.dart';
import 'package:flip_chat/Widgets/three_dots.dart';
import 'package:flip_chat/screens/chat_message.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _messages =[];
  int _responseIndex = 0;
  //List<ChatMessage> get messages => _messages;
  bool _isTyping = false;

  void _sendMessage() async{
    String userMessage = _controller.text;

    ChatMessage userChatMessage = ChatMessage(text: userMessage, sender: "user", isBot: false,);
    setState(() {
      _messages.insert(0, userChatMessage);
      _isTyping = true;
    });
    _controller.clear();

    // Check if user input contains "show" or "image" keyword
    bool set2 = ((userMessage.toLowerCase().contains('image') && userMessage.toLowerCase().contains('formal')) ||
        (userMessage.toLowerCase().contains('show') && userMessage.toLowerCase().contains('formal')) );
    bool isImageRequested = userMessage.toLowerCase().contains('show') ||
                            userMessage.toLowerCase().contains('image');
    String botResponse = isImageRequested && set2 ? 'image formal response' :isImageRequested?'image response' : _getNextResponse();
    await Future.delayed(Duration(seconds: 1));

    ChatMessage botChatMessage = ChatMessage(text: botResponse, sender: "bot", isBot: true);
    setState(() {
      _isTyping=false;
      _messages.insert(0, botChatMessage);
    });

    // Move to the next response
    _responseIndex = (_responseIndex + 1) % hardcodedResponses.length;

  }

  String _getNextResponse() {
    return hardcodedResponses[_responseIndex];
  }

  Widget _buildTextComposer(){/**This is the UI of the text field from where we are giving input to the chat screen.**/
    return  Row(
      children: [
        Expanded(
          child:  Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextField(
              controller: _controller,
              onSubmitted: (value) => _sendMessage(),
              decoration: InputDecoration.collapsed(hintText: 'What you want to search?'),
            ),
          ),
        ),
        SizedBox(width: 8.0,),
        CircleAvatar(
          radius: 25,
          backgroundColor: Color(0xff047BD5),
          child:  IconButton(
              onPressed: () => _sendMessage(),
              icon: const Icon(Icons.send_rounded, color: Color(0xffffffff), size: 30,)),
        ),
      ],
    ).px16();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.black,),
        title: Text('Flip Chat AI', style: TextStyle(color: Colors.black),),
        backgroundColor: Color(0xffffffff),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Divider(height: 1.0,color: Color(0xff9E9E9E),),
            Flexible(
                child:ListView.builder(
                  reverse: true,
                  padding: Vx.m8,
                  itemCount: _messages.isNotEmpty ? _messages.length : initialPrompts.length,
                    itemBuilder: (context, index){
                      if (_messages.isEmpty) {
                        return InitialChatPrompt(text: initialPrompts[index % initialPrompts.length],);
                      }else {
                        // Show chat messages
                        return _messages[index];
                      }
                    })
            ),
            if(_isTyping) ThreeDots(),
            Divider(height: 1.0,),
            Container(  /** This is the text field container**/
              decoration: BoxDecoration(
                color: context.cardColor,
              ),
              child: _buildTextComposer(),
            ),
          ],
        ),
      ),
    );
  }
}
