import 'package:flip_chat/screens/chat_screen.dart';
import 'package:flutter/material.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return  Scaffold(
      appBar: null,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 50,),
            Text('Welcome to \n    FlipChat', style: TextStyle(fontSize: 36, color: Color(0xff047BD5)),),
            SizedBox(height: 20,),
            Image.asset('assets/images/main_logo.png', height: 220, width: 220, fit: BoxFit.fill,),
            SizedBox(height: height*0.3,),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatScreen()));
                },
                style: ElevatedButton.styleFrom(
                  minimumSize:  Size(width*0.8, height*0.08),//320,60
                  backgroundColor: const Color(0xff047BD5),
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20))),
                ),
                child: const Text('Start Chat', style: TextStyle(fontSize: 24)),
              ),
            ),
            SizedBox(height: 30,),
          ],
        ),
      ),
    );
  }
}
