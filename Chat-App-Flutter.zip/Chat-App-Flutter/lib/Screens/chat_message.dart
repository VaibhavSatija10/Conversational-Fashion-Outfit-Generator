import 'package:flip_chat/Widgets/long_rectangle_list.dart';
import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class ChatMessage extends StatelessWidget {
  const ChatMessage({super.key, required this.text, required this.sender, required this.isBot});

  final String text;
  final String sender;
  final bool isBot;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    // Check if the message contains "image" keyword and if it's from bot
    bool isImage = (text.toLowerCase().contains('show') || text.toLowerCase().contains('image')) && isBot;
    bool shouldShowImagesFromSet2 =
        isBot &&
            ((text.toLowerCase().contains('image') &&
                text.toLowerCase().contains('formal')) ||
                (text.toLowerCase().contains('show') &&
                    text.toLowerCase().contains('formal')));

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: width*0.95,
          child: Align(
            alignment: (sender=="user") ?Alignment.topRight: Alignment.topLeft,
            child: Expanded(
                child: SizedBox(
                  width: width*0.8,
                  child: Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                        color: (sender=="user")?Color(0xff047BD5):Color(0xffF5F5F5),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(15.0),
                          topRight: Radius.circular(15.0),
                          bottomLeft: (sender=="user")?Radius.circular(15.0): Radius.circular(0),
                          bottomRight: (sender=="user") ?Radius.circular(0): Radius.circular(15.0),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 1,
                            blurRadius: 5,
                          ),
                        ]),
                    child: isImage ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Here are some image results',
                          style: TextStyle(
                            fontSize: 16,
                            color: (sender == "user")
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        SizedBox(height: 20,),
                        shouldShowImagesFromSet2? LongRectangeList( isimageSet2: true,): LongRectangeList(isimageSet2: false),
                      ],
                    ) : Text(
                      text,
                      style: TextStyle(
                        fontSize: 16,
                        color: (sender == "user")
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
            ),
                )),
          ),
        ),
      ],
    ).py8();
  }
}
