import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

class InitialChatPrompt extends StatelessWidget {
  const InitialChatPrompt({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return  Center(
      child: Column(
        children: [
          Container(
            height: 60,
            width: width*0.9,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Color(0xffEAE8E8),
                borderRadius: BorderRadius.circular(15.0),
            ),
            child: Align(
              alignment: Alignment.center,
              child: Text(text, style: TextStyle(
                fontSize: 16,
                color: Color(0xff9E9E9E),
              ),),
            ),
          ),
        ],
      ).py8(),
    );
  }
}
