import 'package:flip_chat/screens/home_screen.dart';
import 'package:flip_chat/screens/landing_screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    TextEditingController _passwordController = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black,),
          onPressed: () {Navigator.pop(context);},
        ),
        elevation: 0,
      ),
      body:  SingleChildScrollView(
        child: Padding(
          padding:  const EdgeInsets.only(left: 20.0, top: 20, right: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Welcome Back👋', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
              const SizedBox(height: 20,),
              const Text('Please enter your email & password for SignIn', style: TextStyle(color: Color(0xff9E9E9E), fontSize: 14),),
              const SizedBox(height: 60,),
              const Text('Email', style: TextStyle(fontWeight: FontWeight.bold),),
              const TextField(
                decoration: InputDecoration(hintText: 'xyz@gmail.com',hintStyle: TextStyle(fontSize: 14)),
              ),
              const SizedBox(height: 50,),
              const Text('Password', style: TextStyle(fontWeight: FontWeight.bold),),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(hintText: 'password',hintStyle: TextStyle(fontSize: 14)),
                obscureText: true,
              ),
              const SizedBox(height: 20,),
              //TODO: create rememeber me button
              const SizedBox(height: 20,),
              Center(
                child: ElevatedButton(
                  onPressed: () async {
                    await Future.delayed(Duration(seconds: 1));
                    showLoginSuccessfulToast();
                    await Future.delayed(Duration(seconds: 1));
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>LandingScreen()));
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize:  Size(width*0.8, height*0.08),//320,60
                    backgroundColor: const Color(0xff047BD5),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                  ),
                  child: const Text('Login', style: TextStyle(fontSize: 17)),
                ),
              ),
              SizedBox(height: 10,),
              Center(
                child: TextButton(
                  onPressed: () {},
                  child:  Text(
                    'Forgot Password?',
                    style: TextStyle(fontSize: 14, color: const Color(0xff047BD5)),//fontSize: 12.0,
                  ),
                ),
              ),
              Center(
                child: RichText(
                  text: TextSpan(text: 'Don\'t have an account? ', style: TextStyle(fontSize: height*0.019,color:Color(0xff000000)),//fontSize: 17
                      children: <TextSpan>[
                        TextSpan(text: '  Signup', style: TextStyle(fontSize: height*0.021, fontWeight: FontWeight.bold,color: Color(0xff047BD5)),//fontSize: 18
                          recognizer: new TapGestureRecognizer()..onTap = () => Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen())),
                        ),
                      ]
                  ),
                ),
              ),
              SizedBox(height: 30,),
              Center(child: Text('or continue with', style: TextStyle(color: Color(0xff9EAFB0), fontSize: 16),)),
              SizedBox(height: 30,),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  signinButtons(imageurl: 'assets/images/google_logo.png'),
                  signinButtons(imageurl: 'assets/images/flipkart_logo.png'),
                  signinButtons(imageurl: 'assets/images/facebook_logo.png',),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

void showLoginSuccessfulToast() {
  Fluttertoast.showToast(
    msg: "Login Successful",
    toastLength: Toast.LENGTH_LONG,
    gravity: ToastGravity.BOTTOM,
    timeInSecForIosWeb: 1,
    backgroundColor: Colors.green,
    textColor: Colors.white,
    fontSize: 20.0,
  );
}


class signinButtons extends StatelessWidget {
  const signinButtons({
    super.key, required this.imageurl,
  });
  final String imageurl;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80, height: 60,
      decoration:  BoxDecoration(
        border: Border.all(width: 1, color: Color(0xffEFEEEE)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Image.asset(imageurl),
    );
  }
}
